# WEBL — imagen inicial DESORDEN

## Sustituir estos archivos

- `public/index.html`
- `public/app.js`
- `public/opening-profile.css`
- `public/assets/intro-profile-2160.avif`

No es necesario modificar `public/scenes.js` ni `public/styles.css`.

## Resultado

1. La imagen adjunta aparece como primer frame de carga y primera escena.
2. La barra lateral entra progresivamente.
3. Al deslizar, la cámara se aproxima al ojo y la nariz sin blur.
4. El retrato se desplaza lateralmente, simulando que la cámara pasa por delante del rostro.
5. Después aparece el primer bloque original.

## Imagen

- Formato: AVIF
- Resolución: 2160 × 3840 px
- Proporción: 9:16
- Perfil: RGB/sRGB
- Peso aproximado: 245 KB
